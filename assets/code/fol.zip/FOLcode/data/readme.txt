Dataset Information

CIFAR-10 and CIFAR-100** are publicly available datasets. 

Wildfire Dataset: Collected by Abdelghani Aaba and their research team. It can be accessed at the following link:  
  [Wildfire Prediction Dataset](https://www.kaggle.com/datasets/abdelghaniaaba/wildfire-prediction-dataset/data).

Hurricane Dataset: Collected by Yuem Park and their research team. It is available at:  
  [Satellite Images of Hurricane Damage](https://www.kaggle.com/code/yuempark/satellite-images-of-hurricane-damage).

Please download them and place them in this directory.
